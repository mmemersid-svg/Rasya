// ===================================
// === Inisialisasi & Konfigurasi Sesi ===
// ===================================

const startBtn = document.getElementById('start-sesi-btn');
const timerEl = document.getElementById('timer-display');
const countEl = document.getElementById('punch-count');
const targetEl = document.getElementById('display-target');
const powerEl = document.getElementById('display-power');
const messageEl = document.getElementById('session-message');

let timerInterval;
let isSessionActive = false;
let minPeak ;

// Konfigurasi Sesi
const level = sessionStorage.getItem('punchModeLevel') || 'easy'; 
let duration, targetCount;

if (level === 'hard') {
    duration = 1 * 60; 
    targetCount = 200;
    minPeak= 6.0;
} else {
    duration = 3 * 60; 
    targetCount = 200;
    minPeak=1.5;
}
let timeRemaining = duration;

// Variabel Akselerometer (Moving Average)
let movementBuffer = [];
const bufferSize = 10; 
let lastZ = 0;
let punchCount = 0;

// ===================================
// === Fungsi Akselerometer & Deteksi Pukulan ===
// ===================================

function handleMotionEvent(event) {
    if (!isSessionActive) return;

    let z = event.accelerationIncludingGravity.z || 0;
    
    // Moving Average
    movementBuffer.push(z);
    if (movementBuffer.length > bufferSize) {
        movementBuffer.shift(); 
    }
    let avgZ = movementBuffer.reduce((a,b) => a+b, 0) / movementBuffer.length;
    
    // Tampilkan power
    powerEl.textContent = avgZ.toFixed(1); 

    // Peak Detection
    if(avgZ - lastZ > minPeak){ 
        punchCount++; 
        countEl.textContent = punchCount; 
        
        // Cek Target
        if (punchCount >= targetCount) {
             endSession("TARGET TERCAPAI!");
        }
    }
    
    lastZ = avgZ; 
}

// ===================================
// === Fungsi Timer & Kontrol Sesi ===
// ===================================

function updateTimerDisplay() {
    const minutes = Math.floor(timeRemaining / 60);
    const seconds = timeRemaining % 60;
    
    timerEl.textContent = 
        `${String(minutes).padStart(2, '0')}:${String(seconds).padStart(2, '0')}`;
}

function startSensorAndTimer() {
    // Fungsi ini dipanggil HANYA setelah izin sensor berhasil atau tidak diperlukan.
    window.addEventListener('devicemotion', handleMotionEvent, true);
    isSessionActive = true;
    startBtn.disabled = true;
    messageEl.textContent = "BERLANGSUNG...";
    
    timerInterval = setInterval(() => {
        timeRemaining--;
        updateTimerDisplay();

        if (timeRemaining <= 0) {
            endSession("WAKTU HABIS!");
        }
    }, 1000);
}

function startSession() {
    if (isSessionActive) return; 
    
    startBtn.textContent = "Loading..."; // Feedback visual

    if (window.DeviceMotionEvent) {
        if (typeof DeviceMotionEvent.requestPermission === 'function') {
            // Logika Izin iOS
            DeviceMotionEvent.requestPermission().then(permissionState => {
                if (permissionState === 'granted') {
                    startSensorAndTimer();
                } else {
                    messageEl.textContent = "Izin Sensor Ditolak. (Klik tombol lagi)";
                    startBtn.textContent = "Mulai Sesi"; // Kembalikan teks tombol agar bisa dicoba lagi
                    startBtn.disabled = false;
                }
            }).catch(error => {
                messageEl.textContent = "Error Sensor Izin.";
                startBtn.textContent = "Mulai Sesi";
                startBtn.disabled = false;
                console.error("Izin Sensor Gagal:", error);
            });
        } else {
            // Logika Android/Non-iOS (Tidak perlu izin klik)
            startSensorAndTimer();
        }
    } else {
        messageEl.textContent = "Sensor Tidak Didukung.";
        startBtn.disabled = true;
    }
}

function endSession(message) {
    clearInterval(timerInterval);
    isSessionActive = false;
    window.removeEventListener('devicemotion', handleMotionEvent, true);
    startBtn.textContent = "Sesi Selesai";
    startBtn.disabled = true;
    messageEl.textContent = message;
    
    console.log(`Sesi selesai: ${punchCount} hits.`);
}


// ===================================
// === Inisialisasi Awal Halaman (Listener) ===
// ===================================

document.addEventListener('DOMContentLoaded', () => {
    // Tampilkan konfigurasi awal
    targetEl.textContent = targetCount;
    updateTimerDisplay(); 
    
    // Teks tombol awal
    if (typeof DeviceMotionEvent.requestPermission === 'function') {
         startBtn.textContent = "Mulai & Beri Izin";
    }

    // Set listener tombol start (TIDAK PAKAI { once: true } lagi untuk kasus error izin)
    startBtn.addEventListener('click', startSession); 
});